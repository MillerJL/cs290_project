//var request = require('request');
//handle text
function handleText(text) {
  var lower = text.toLowerCase();
  lower = lower.replace(/[^a-zA-Z0-9 ]+/g, '').replace('/ {2,}/',' ');
  lower = lower.split(" ");
  return lower;
}
// what gets required by the app.
module.exports = function (req, res, next) {
  var request = require('request');
  var text = handleText(req.body.text);

  var obj = {
    words: [],
    counts: []
  }

  for (var i = 0; i < text.length; i++) {
    var exists = false;
    for (var j = 0; j < obj.words.length; j++) {
      if (text[i] == obj.words[j]) {
        exists = true;
        obj.counts[j] = obj.counts[j] + 1;
      }
    }
    if (!exists) {
      obj.words.push(text[i]);
      obj.counts.push(1);
    }
    exists = false;
  }

  console.log(obj);
// Sanity check. We don't want our slackbot to make this shit infinite.
  request.post('http://localhost:3000/chat', {form:{key:obj}})
  var userName = "test";
  if (userName !== 'slackbot') {
    return res.status(200).json({
      text: "shane"
    });
  } else {
    return res.status(200).end();
  }
}
